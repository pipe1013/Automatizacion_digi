from time import sleep
from typing import KeysView
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.service import Service as ChromeService
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.keys import Keys






# Datos de credito
driver = webdriver.Chrome(service=ChromeService(ChromeDriverManager().install()))
driver.implicitly_wait(2)
driver.maximize_window()
driver.get("https://digicredito-dev2.excelcredit.co/login")
wait = WebDriverWait(driver, 10)

#Login
driver.find_element(By.ID, 'login-button').click()
driver.find_element(By.ID, 'username').send_keys("jtellez@excelcredit.co")
driver.find_element(By.ID, 'password').send_keys("Suaita01")
driver.find_element(By.NAME, 'login').click()
sleep(10)
driver.get("https://digicredito-dev2.excelcredit.co/admin/simulator")
sleep(10)

# wait.until(EC.visibility_of_element_located((By.XPATH, '//*[@id="main-page"]/div[2]/div/div/div[1]/svg')))
# driver.find_element(By.XPATH, '//*[@id="main-page"]/div[2]/div/div/div[1]/svg').click()

#Seleccion de oficina
driver.find_element(By.ID, 'Oficina').click()

sleep(5)

# DATOS COMPLEMENTARIOS
driver.find_element(By.ID, 'paisNacimiento2').send_keys("")
driver.find_element(By.ID, 'lugarNacimiento2').send_keys("")